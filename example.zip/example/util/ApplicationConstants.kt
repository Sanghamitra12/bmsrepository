package com.example.util

/**
 * Created by 397947 on 5/24/2017.
 */

object ApplicationConstants {

    var REGULATORY_NODE: String = "PartyC"
    var UPLOAD_LOCATION = "/home/ubuntu/"
    var Lessor: String = "PartyA"
    var Lessee: String = "PartyB"
    var Admin: String = "PartyD"

    var REGULATORY_PORT: String = "59005"
    var Lessor_PORT: String = "59003"
    var Lessee_PORT: String = "59004"
    var Admin_PORT: String = "59006"
    val CONTROLLER: String = "Controller"

    val CREATECONTRACT: String="Contract created by Lessor"
    val SUBMITCONTRACT: String="Contract submitted by Lessor"
    val SENDBACKREVIEW: String="Contract sentback for revision"
    val SAVECONTRACT: String="Lessor save the contract"
    val SIGNCONTRACT:String="Contract signed by Lessee"
    val FULLYSIGNED:String ="Contract signed by Lessor"
    val ADMINAPPROVAL:String="Waiting for admin approval"
    val ASSETAPPROVED:String="Asset approved by admin"
    val FALSE=false
    val TRUE=true




}

