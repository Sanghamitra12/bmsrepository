package com.example.dao

import com.example.connection.DatabaseConnection
//import com.example.transfer.ContractDTO
//import com.example.transfer.UserDetailsDTO
//import com.example.transfer.ViewDTO
import com.example.DTO.UserDTO
import com.example.DTO.ContractDTO
import com.example.DTO.AssetDTO
import com.example.DTO.FileDTO
import com.example.DTO.UserDetailsDTO
import com.example.DTO.PaymentDTO
import com.example.DTO.LesseeDTO
import com.example.DTO.detailDTO
import com.example.DTO.FileStatusDTO
import com.example.model.filedetail
import java.text.SimpleDateFormat
//import com.example.model.UserDetails
import java.sql.*
import java.time.Instant


/**
 * Created by 397947 on 5/26/2017.
 */

class ApplicationDao {

//    fun viewCustomer(nodeName: String, contract_name : String): List<ContractDTO> {
//    println("inside the viewContract")
//        println(contract_name)
//        val  connection = DatabaseConnection.getConnection(nodeName)
//        var customerList : MutableList<ContractDTO> = mutableListOf()
//        println("customerList--"+customerList)
//        var statement: PreparedStatement? = null
//        var rs: ResultSet? = null
//
//        var whereClause = StringBuilder()
//
//        try {
//            if(null!=contract_name && !"".equals(contract_name.trim())){
//                whereClause.append(" AND contract_name=?")
//            }
//          //  val sql: String? = "SELECT contract_id AS contract_id, contract_name, lesse_name, description, start_date, end_date, frequency from RegisterCustomer where contract_name=contract_name"
//            val sql: String? ="select * from createcontract order by contract_name"
//            statement = connection.prepareStatement(sql)
//
//            System.out.println("SQL: "+sql.toString())
//            System.out.println("Statement: "+statement.toString())
//            rs = statement.executeQuery()
//            println(rs)
//            var customer : ContractDTO? = null
//            while (rs.next()) {
//                customer = ContractDTO(rs.getString("contract_id"), rs.getString("contract_name"), rs.getString("description"), rs.getString("start_date"), rs.getString("end_date"), rs.getString("frequency"),rs.getInt("amount"),rs.getString("lessor_id"), rs.getString("lesse_id"),rs.getString("status"),rs.getString("comments"))
//                if(null != customer){
//                    customerList.add(customer)
//                }
//            }
//
//
//        } catch (se: SQLException) {
//            System.out.println(se.message)
//        } finally {
//           // closeConnection(connection, statement, rs)
//        }
//        return customerList
//    }
//
//    fun searchUser(nodeName: String, hostName: String,user_id: String,user_type: String,password: String ): List<UserDTO> {
//        println("inside the viewContract")
//
//        val  connection = DatabaseConnection.getConnection(nodeName)
//        var customerList : MutableList<UserDTO> = mutableListOf()
//        var statement: PreparedStatement? = null
//        var rs: ResultSet? = null
//
//        var whereClause = StringBuilder()
//
//        try {
//            if(null!=user_id && !"".equals(user_id.trim())){
//                whereClause.append(" AND user_id=?")
//            }
//            //  val sql: String? = "SELECT contract_id AS contract_id, contract_name, lesse_name, description, start_date, end_date, frequency from RegisterCustomer where contract_name=contract_name"
//            val sql: String? ="select user_type,password,user_id  from createuser where user_id=?"
//
//
//            statement = connection.prepareStatement(sql)
//            statement.setString(1, user_id);
//            System.out.println("SQL: "+sql.toString())
//            System.out.println("Statement: "+statement.toString())
//            rs = statement.executeQuery()
//            println(rs)
//            var customer : UserDTO? = null
//            while (rs.next()) {
//                customer = UserDTO(rs.getString("user_id"), rs.getString("password"), rs.getString("user_type"))
//                if(null != customer){
//                    customerList.add(customer)
//                }
//            }
//
//
//        } catch (se: SQLException) {
//            System.out.println(se.message)
//        } finally {
//            // closeConnection(connection, statement, rs)
//        }
//        return customerList
//    }
//
//
//    fun createLessor(nodeName: String,name: String,address: String,contact_no: String,city: String,state: String,country: String,zipcode: String):Int {
//        var a: Int=0
//        println("inside dao")
//        println(nodeName)
//        val  connection = DatabaseConnection.getConnection(nodeName)
//        println("connectionof table"+connection)
//        println("inside the table creation")
//        var statement: PreparedStatement? = null
//        var rs: ResultSet? = null
//
//        try {
//            val sql: String? = "CREATE TABLE IF NOT EXISTS createLessor3 (lessor_id VARCHAR(50) PRIMARY KEY, name VARCHAR(50) NULL, address VARCHAR(50) NULL, contact_no VARCHAR(50) NULL, city VARCHAR(50) NULL, state VARCHAR(50) NULL ,country VARCHAR(20) NULL, zipcode VARCHAR(50) NULL)"
//
//            statement = connection.prepareStatement(sql)
//
//            statement.execute()
//            println("tablestatement-->"+statement)
//            println("table created")
//
//            val sql1: String? = "INSERT INTO createLessor3( lessor_id, name, address, contact_no, city, state, country, zipcode) VALUES (?,?,?,?,?,?,?,?)"
//            println("table created")
//
//                statement = connection.prepareStatement(sql1)
//
//            var lessorid = "Les"+(Math.abs(Math.ceil(Math.random()*1000000))).toString().replace(".0","")
//
//                        //statement.setString(1,"2334")
//                statement.setString(1, lessorid)
//                statement.setString(2, name)
//                statement.setString(3, address)
//                statement.setString(4, contact_no)
//                statement.setString(5, city)
//                statement.setString(6, state)
//                statement.setString(7, country)
//                statement.setString(8, zipcode)
//                println(statement)
//
//
//                statement.executeUpdate()
//                a=1
//                println("values inserted")
//
//        } catch (se: SQLException) {
//            System.out.println(se.message)
//
//
//
//
//        } finally {
//            //closeConnection(connection, statement, rs)
//        }
//            return a
//    }
//
//    fun createRegisterTable(nodeName: String) {
//        println("inside dao")
//        println(nodeName)
//        val  connection = DatabaseConnection.getConnection(nodeName)
//        println("connectionof table"+connection)
//       println("inside the table creation")
//        var statement: PreparedStatement? = null
//        var rs: ResultSet? = null
//
//        try {
//            val sql: String? = "CREATE TABLE IF NOT EXISTS createcontract (contract_id VARCHAR(50) PRIMARY KEY, contract_name VARCHAR(50) NULL, description VARCHAR(50) NULL, start_date VARCHAR(50) NULL, end_date VARCHAR(50) NULL, frequency VARCHAR(50) NULL ,amount INT NULL, lessor_id VARCHAR(50) NULL, lesse_id VARCHAR(50) NULL, status VARCHAR(50) NULL, comments VARCHAR(50) NULL)"
//
//            statement = connection.prepareStatement(sql)
//
//            statement.execute()
//            println("tablestatement-->"+statement)
//            println("table created")
//        } catch (se: SQLException) {
//            System.out.println(se.message)
//        } finally {
//           //closeConnection(connection, statement, rs)
//        }
//    }
////
//    fun  insertRegisterCustomer(nodeName: String, customersFromVault: MutableList<ContractDTO>) {
//    println("inside the DTO")
//        val  connection = DatabaseConnection.getConnection(nodeName)
//        println("customer from valult-->"+customersFromVault)
//        var statement: PreparedStatement? = null
//        var rs: ResultSet? = null
//    try {
//        val sql: String? = "INSERT INTO createcontract(contract_id, contract_name,  description, start_date, end_date, frequency, amount, lessor_id, lesse_id, status ,comments) VALUES (?,?,?,?,?,?,?,?,?,?,?)"
//        println("table created")
//        println(customersFromVault)
//        for(customer in customersFromVault) {
//            statement = connection.prepareStatement(sql)
//
//            statement.setString(1, customer.contract_id)
//            statement.setString(2, customer.contract_name)
//            statement.setString(3, customer.description)
//            statement.setString(4, customer.start_date)
//           statement.setString(5, customer.end_date)
//           statement.setString(6, customer.frequency)
//           statement.setInt(7, customer.amount)
//           statement.setString(8, "123")
//           statement.setString(9, "133")
//           statement.setString(10, "345")
//            statement.setString(11, "345")
//
//
//            println(statement)
//
//
//            statement.executeUpdate()
//                println("values inserted")
//            }
//
//        } catch (se: SQLException) {
//            System.out.println(se.message)
//        } finally {
//           // closeConnection(connection, statement, rs)
//        }
//    }
//

//    fun createuser(nodeName: String) {
//        println("inside dao")
//        println(nodeName)
//        val  connection = DatabaseConnection.getConnection(nodeName)
//        println("connectionof table"+connection)
//        println("inside the table creation")
//        var statement: PreparedStatement? = null
//        var rs: ResultSet? = null
//
//        try {
//            val sql: String? = "CREATE TABLE IF NOT EXISTS userTable1 (user_id VARCHAR(50) PRIMARY KEY, user_type VARCHAR(50) NULL,password VARCHAR(50) NULL,)"
//
//            statement = connection.prepareStatement(sql)
//
//            statement.execute()
//            println("tablestatement-->"+statement)
//            println("table created")
//        } catch (se: SQLException) {
//            System.out.println(se.message)
//        } finally {
//            //closeConnection(connection, statement, rs)
//        }
//    }

    fun  userLogin(nodeName: String, customersFromVault: List<UserDTO>):String {
        println("inside the DTO")
        val  connection = DatabaseConnection.getConnection(nodeName)
        println("customer from valult-->"+customersFromVault)
        var statement: PreparedStatement? = null
        var rs: ResultSet? = null
        var msg:String=""
        var user_name:String=""
        try {
            val sql1: String? = "CREATE TABLE IF NOT EXISTS userTableDetails5 (user_id varchar(50) REFERENCES UserDetailsT1(user_id),user_name varchar(50) NULL,password Varchar(40) NULL,user_type Varchar(50) NULL)"
            statement = connection.prepareStatement(sql1)
            statement.execute()
            val sql: String? = "INSERT INTO userTableDetails5(user_id,user_name,password,user_type) VALUES (?,?,?,?)"
            println("table created")
            println(customersFromVault)
            for(customer in customersFromVault) {
                statement = connection.prepareStatement(sql)
                user_name=customer.user_id+"@"+customer.user_type+".com"
                statement.setString(1, customer.user_id)
                statement.setString(2, user_name)
                statement.setString(3, customer.password)
                statement.setString(4, customer.user_type)



                println(statement)


                statement.executeUpdate()
                msg="Successfully created"
                println("values inserted")
            }

        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
            // closeConnection(connection, statement, rs)
        }
        return user_name
    }

    fun searchUser(nodeName: String, hostName: String,user_name: String?,password: String,user_type: String): List<UserDTO> {
        println("inside the viewContract")
        println(nodeName)
        val  connection = DatabaseConnection.getConnection(nodeName)
        println("connection"+connection)
        var customerList : MutableList<UserDTO> = mutableListOf()
        var statement: PreparedStatement? = null
        var rs: ResultSet? = null

        var whereClause = StringBuilder()

        try {

            //  val sql: String? = "SELECT contract_id AS contract_id, contract_name, lesse_name, description, start_date, end_date, frequency from RegisterCustomer where contract_name=contract_name"
            val sql: String? ="select user_id, user_name,password,user_type  from userTableDetails5 where user_name=?"


            statement = connection.prepareStatement(sql)
            statement.setString(1, user_name);
            System.out.println("SQL: "+sql.toString())
            System.out.println("Statement: "+statement.toString())
            rs = statement.executeQuery()
            println(rs)
            var customer : UserDTO? = null
            while (rs.next()) {
                customer = UserDTO(rs.getString("user_id"),rs.getString("user_name"),rs.getString("password"),rs.getString("user_type"))
                if(null != customer){
                    customerList.add(customer)
                }
            }


        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
            // closeConnection(connection, statement, rs)
        }
        return customerList
    }


    fun getLesseeDetails(nodeName: String): List<LesseeDTO> {
        println("inside the viewContract")
        println(nodeName)
        val  connection = DatabaseConnection.getConnection(nodeName)
        println("connection"+connection)
        var customerList : MutableList<LesseeDTO> = mutableListOf()
        var statement: PreparedStatement? = null
        var rs: ResultSet? = null

        var whereClause = StringBuilder()

        try {

            //  val sql: String? = "SELECT contract_id AS contract_id, contract_name, lesse_name, description, start_date, end_date, frequency from RegisterCustomer where contract_name=contract_name"
            val sql: String? ="select user_id from userTableDetails5 where user_type=?"


            statement = connection.prepareStatement(sql)
            statement.setString(1, "Lessee");
            System.out.println("SQL: "+sql.toString())
            System.out.println("Statement: "+statement.toString())
            rs = statement.executeQuery()
            println(rs)
            var customer : LesseeDTO? = null
            while (rs.next()) {
                customer = LesseeDTO(rs.getString("user_id"))
                if(null != customer){
                    customerList.add(customer)
                }
            }


        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
            // closeConnection(connection, statement, rs)
        }
        return customerList
    }

    fun getpaymentDetails(nodeName: String,id: String): List<detailDTO> {
        println("inside the viewContract")
        println(nodeName)
        val  connection = DatabaseConnection.getConnection(nodeName)
        println("connection"+connection)
        var details : MutableList<detailDTO> = mutableListOf()
        var statement: PreparedStatement? = null
        var rs: ResultSet? = null

        var whereClause = StringBuilder()

        try {

            //  val sql: String? = "SELECT contract_id AS contract_id, contract_name, lesse_name, description, start_date, end_date, frequency from RegisterCustomer where contract_name=contract_name"
            val sql: String? ="select paymentmonth,status  from paymentschedule5 where contract_id=? order by paymentmonth asc"


            statement = connection.prepareStatement(sql)
            statement.setString(1, id);
            System.out.println("SQL: "+sql.toString())
            System.out.println("Statement: "+statement.toString())
            rs = statement.executeQuery()
            println(rs)
            var customer : detailDTO? = null
            while (rs.next()) {
              val dat=rs.getDate("paymentmonth").toString()
                customer = detailDTO(dat,rs.getString("status"))
                println("details"+customer)
                if(null != customer){
                    details.add(customer)
                }
            }


        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
            // closeConnection(connection, statement, rs)
        }
        return details
    }



    fun createContractDetails(nodeName: String,otherparty: String) {
        println("inside dao")
        println(nodeName)
        val  connection = DatabaseConnection.getConnection(nodeName)
        val  connection1 = DatabaseConnection.getConnection(otherparty)
        println("connectionof table"+connection)
        println("inside the table creation")
        var statement: PreparedStatement? = null
        var statement1: PreparedStatement? = null
        var rs: ResultSet? = null

        try {


            val sql: String? = "CREATE TABLE IF NOT EXISTS contractDetailsTableTT5 (contract_id VARCHAR(50) PRIMARY KEY,AssetRefID Varchar(50),contract_name VARCHAR(50) NULL, description VARCHAR(50) NULL, start_date Date NULL, end_date Date NULL, frequency VARCHAR(50) NULL ,amount Float NULL, lessor_id VARCHAR(50) NULL, lesse_id VARCHAR(50) NULL, status VARCHAR(50) NULL, comments VARCHAR(50) NULL,breachPeriod Int NULL)"

            statement = connection.prepareStatement(sql)
            statement1=connection1.prepareStatement(sql)

            println("tablestatement-->"+statement)
            println("tablestatement-->"+statement1)

            statement.execute()
            statement1.execute()
            val sql1: String? = "CREATE TABLE IF NOT EXISTS paymentListTableTT5(contract_id varchar(50) NULL,amount Float NULL,duedate Date NULL)"

            statement = connection.prepareStatement(sql1)
            statement1 = connection1.prepareStatement(sql1)

            statement.execute()
            statement1.execute()


            println("tablestatement-->"+statement)
            println("tablestatement-->"+statement1)
            println("table created")
        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
            //closeConnection(connection, statement, rs)
        }
    }
    //
    fun  insertcontractdetails(nodeName: String,otherparty: String, customersFromVault: List<ContractDTO>):String {
        println("inside the DTO")
        val  connection = DatabaseConnection.getConnection(nodeName)
        val  connection1 = DatabaseConnection.getConnection(otherparty)
        println("customer from valult-->"+customersFromVault)
        var statement: PreparedStatement? = null
        var statement1: PreparedStatement? = null
        var rs: ResultSet? = null
        var contract_id:String=""
        try {
            val sql: String? = "INSERT INTO contractDetailsTableTT5(contract_id,AssetRefID, contract_name,  description, start_date, end_date, frequency, amount, lessor_id, lesse_id, status ,comments,breachPeriod) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)"
            println("table created")
            println(customersFromVault)
            for(customer in customersFromVault) {
                statement = connection.prepareStatement(sql)
                statement1 = connection1.prepareStatement(sql)
                contract_id = "Contract"+(Math.abs(Math.ceil(Math.random()*1000000))).toString().replace(".0","")
                statement.setString(1, contract_id)
                statement.setString(2,customer.AssetRefID)
                statement.setString(3, customer.contract_name)
                statement.setString(4, customer.description)
                statement.setDate(5, Date.valueOf(customer.start_date))
                statement.setDate(6, Date.valueOf(customer.end_date))
                statement.setString(7, customer.frequency)
                statement.setFloat(8, customer.amount)
                statement.setString(9, customer.lessor_id)
                statement.setString(10, customer.lesse_id)
                statement.setString(11, customer.status)
                statement.setString(12, customer.comments)
                statement.setString(12, customer.comments)
                statement.setInt(13, customer.breachPeriod)

                statement1.setString(1, contract_id)
                statement1.setString(2,customer.AssetRefID)
                statement1.setString(3, customer.contract_name)
                statement1.setString(4, customer.description)
                statement1.setDate(5, Date.valueOf(customer.start_date))
                statement1.setDate(6, Date.valueOf(customer.end_date))
                statement1.setString(7, customer.frequency)
                statement1.setFloat(8, customer.amount)
                statement1.setString(9, customer.lessor_id)
                statement1.setString(10, customer.lesse_id)
                statement1.setString(11, customer.status)
                statement1.setString(12, customer.comments)
                statement1.setString(12, customer.comments)
                statement1.setInt(13, customer.breachPeriod)
                println(statement)


                statement.executeUpdate()
                statement1.executeUpdate()
                println("values inserted")
            }

            val sql1: String? = "INSERT INTO paymentListTableTT5(contract_id,amount, duedate) VALUES (?,?,?)"
            println("table created")
            println()
            for(customer in customersFromVault) {
                statement = connection.prepareStatement(sql1)
                statement1 = connection1.prepareStatement(sql1)
                for(payment in customer.paymentDetails) {
                    statement.setString(1,contract_id)
                    statement.setFloat(2, payment.amount)
                    statement.setDate(3, Date.valueOf(payment.duedate))
                    statement1.setString(1,contract_id)
                    statement1.setFloat(2, payment.amount)
                    statement1.setDate(3, Date.valueOf(payment.duedate))
                    println(statement)
                    statement.executeUpdate()
                    statement1.executeUpdate()
                    println("values inserted")
                }

            }

        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
            // closeConnection(connection, statement, rs)
        }
        return contract_id
    }
    fun getContractDetails(nodeName: String ): List<ContractDTO> {
        println("inside the viewContract")
        println(nodeName)
        val  connection = DatabaseConnection.getConnection(nodeName)
        println("connection"+connection)
        var contractList : MutableList<ContractDTO> = mutableListOf()
        var paymentList : MutableList<PaymentDTO> = mutableListOf()
        var statement: PreparedStatement? = null
        var rs: ResultSet? = null
        var rs1: ResultSet? = null
        var formatter = SimpleDateFormat("yyyy-MM-dd")
        var whereClause = StringBuilder()

        try {
            //  val sql: String? = "SELECT contract_id AS contract_id, contract_name, lesse_name, description, start_date, end_date, frequency from RegisterCustomer where contract_name=contract_name"
            val sql: String? ="select * from  contractDetailsTableTT5 order by contract_id "
            statement = connection.prepareStatement(sql)
            System.out.println("SQL: "+sql.toString())
            System.out.println("Statement: "+statement.toString())
            rs = statement.executeQuery()
            println(rs)
            var contract : ContractDTO? = null
            var payment :PaymentDTO?=null
            while (rs.next()) {
                paymentList = mutableListOf()
//                    var paymentDetailList =(rs.getString("paymentDetails"))
                val sql1: String? ="select * from  paymentListTableTT5 where contract_id =? "
                statement = connection.prepareStatement(sql1)
                statement.setString(1, rs.getString("contract_id"));
                System.out.println("SQL: "+sql1.toString())
                System.out.println("Statement: "+statement.toString())
                rs1 = statement.executeQuery()
                println("paymnet--->"+rs1)
                while(rs1.next())
                {

                    var dueDate:String = formatter.format(rs1.getDate("duedate"))
                   // String duedate=rs1.getDate("duedate")
                    payment=PaymentDTO(rs1.getFloat("amount"),dueDate)
                    println("payment"+payment)
                    paymentList.add(payment)
                    println("paymentList"+paymentList)
                }
                var startDate:String = formatter.format(rs.getDate("start_date"))
                var endDate:String = formatter.format(rs.getDate("end_date"))
//                    println(paymentDetailList.toCharArray())
                contract = ContractDTO(rs.getString("contract_id"),rs.getString("AssetRefID") ,rs.getString("contract_name"), rs.getString("description"),startDate,endDate,rs.getString("frequency"),rs.getFloat("amount"),rs.getString("lessor_id"),rs.getString("lesse_id"),rs.getString("status"),rs.getString("comments"),paymentList,rs.getInt("breachPeriod"))

                if(null != contract){

                    contractList.add(contract)
                }
            }


        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
            // closeConnection(connection, statement, rs)
        }
        return contractList
    }

//
    fun changeAsset(Lessornode: String,LesseeNode: String,Adminnode: String,asset_id:String?) {
        println("inside the changeasset")
        println("asset id------------------------------------------------------------>"+asset_id)
        println(Lessornode)
        val  connection = DatabaseConnection.getConnection(Lessornode)
        val  connection1 = DatabaseConnection.getConnection(LesseeNode)
        val  connection2 = DatabaseConnection.getConnection(Adminnode)
        println("connection"+connection)
        println("connection1"+connection1)
        println("connection2"+connection2)
        var assetList : MutableList<AssetDTO> = mutableListOf()
        var statement1: PreparedStatement? = null
        var statement2: PreparedStatement? = null
        var statement3: PreparedStatement? = null
        var rs: ResultSet? = null

        var whereClause = StringBuilder()

        try {

            //  val sql: String? = "SELECT contract_id AS contract_id, contract_name, lesse_name, description, start_date, end_date, frequency from RegisterCustomer where contract_name=contract_name"
            val sql: String? ="select * from AssetDetailsTableT5 where asset_id=?"

            statement1 = connection.prepareStatement(sql)
            statement1.setString(1,asset_id)
            System.out.println("SQL: "+sql.toString())
            System.out.println("Statement: "+statement1.toString())
            rs = statement1.executeQuery()
            println("rsvalues"+rs)
            var asset : AssetDTO? = null
            while (rs.next()) {
                asset = AssetDTO(rs.getString("asset_id"), rs.getString("name"), rs.getString("address"),rs.getString("city"),rs.getString("state"),rs.getString("country"),rs.getString("zipcode"),rs.getString("lessor_id"),rs.getString("currentOccupantID"),rs.getString("status"),rs.getString("approvedBy"))
                if(null != asset){
                    assetList.add(asset)
                }
            }
            println("Assetdetails"+assetList)

            val sql1: String? = "CREATE TABLE IF NOT EXISTS AssetDetailsTableT5 (asset_id VARCHAR(50) PRIMARY KEY, name VARCHAR(50) NULL, address VARCHAR(50) NULL, city VARCHAR(50) NULL, state VARCHAR(50) NULL ,country VARCHAR(20) NULL, zipcode VARCHAR(50) NULL,lessor_id VARCHAR(50) NOT NULL,currentOccupantID VARCHAR(50) NULL, status VARCHAR(50) NULL, approvedBy VARCHAR(50) NULL)"
            statement2 = connection1.prepareStatement(sql1)
            statement2.execute()
            println("tablestatement-->"+statement2)
            println("table created")

            val sql2: String? = "INSERT INTO AssetDetailsTableT5(asset_id, name, address, city, state, country, zipcode,lessor_id,currentOccupantID,status,approvedBy) VALUES (?,?,?,?,?,?,?,?,?,?,?)"
            println("table created")
            for(asset in assetList) {
                statement2 = connection1.prepareStatement(sql2)
                statement2.setString(1, asset_id)
                statement2.setString(2, asset.name)
                statement2.setString(3, asset.address)
                statement2.setString(4, asset.city)
                statement2.setString(5, asset.state)
                statement2.setString(6, asset.country)
                statement2.setString(7, asset.zipcode)
                statement2.setString(8, asset.lessor_id)
                statement2.setString(9,asset.currentOccupantID)
                statement2.setString(10, "Rented")
                statement2.setString(11, asset.approvedBy)
                println(statement2)
                statement2.executeUpdate()
                println("values inserted")
            }
            val sql3: String? = "Update AssetDetailsTableT5 set status=? where asset_id =?"
            statement1 = connection.prepareStatement(sql3)
            statement3 = connection2.prepareStatement(sql3)
            statement1.setString(1, "Rented")
            statement1.setString(2, asset_id)
            statement3.setString(1, "Rented")
            statement3.setString(2,asset_id)
            println(statement3)
            println(statement1)
            statement1.executeUpdate()
            statement3.executeUpdate()

        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
            // closeConnection(connection, statement, rs)
        }
    }

    fun createAsset(Lessornode: String,Adminnode: String,assetDetails: List<AssetDTO>): String {
        println("inside dao")
        println(Lessornode)
        var    asset_id=""
        val  connection = DatabaseConnection.getConnection(Lessornode)
        val connection1 = DatabaseConnection.getConnection(Adminnode)
        println("connection1")
        println("connectionof table"+connection)
        println("inside the table creation")
        var statement: PreparedStatement? = null
        var statement1: PreparedStatement? = null
        // var rs: ResultSet? = null


        try {
            val sql: String? = "CREATE TABLE IF NOT EXISTS AssetDetailsTableT5 (asset_id VARCHAR(50) PRIMARY KEY, name VARCHAR(50) NULL, address VARCHAR(50) NULL, city VARCHAR(50) NULL, state VARCHAR(50) NULL ,country VARCHAR(20) NULL, zipcode VARCHAR(50) NULL,lessor_id VARCHAR(50) NOT NULL,currentOccupantID VARCHAR(50) NULL, status VARCHAR(50) NULL, approvedBy VARCHAR(50) NULL)"
            statement = connection.prepareStatement(sql)
            statement1 = connection1.prepareStatement(sql)
            statement.execute()
            statement1.execute()
            println("tablestatement-->"+statement)
            println("table created")

            asset_id = "Asset"+(Math.abs(Math.ceil(Math.random()*1000000))).toString().replace(".0","")
            val sql1: String? = "INSERT INTO AssetDetailsTableT5(asset_id, name, address, city, state, country, zipcode,lessor_id,currentOccupantID,status,approvedBy) VALUES (?,?,?,?,?,?,?,?,?,?,?)"
            println("table created")
            println("Asset-->"+assetDetails)

            for(asset in assetDetails) {
                statement = connection.prepareStatement(sql1)
                statement1 = connection1.prepareStatement(sql1)
                statement.setString(1, asset_id)
                statement.setString(2, asset.name)
                statement.setString(3, asset.address)
                statement.setString(4, asset.city)
                statement.setString(5, asset.state)
                statement.setString(6, asset.country)
                statement.setString(7, asset.zipcode)
                statement.setString(8, asset.lessor_id)
                statement.setString(9,asset.currentOccupantID)
                statement.setString(10, asset.status)
                statement.setString(11, asset.approvedBy)
                statement1.setString(1,asset_id)
                statement1.setString(2, asset.name)
                statement1.setString(3, asset.address)
                statement1.setString(4, asset.city)
                statement1.setString(5, asset.state)
                statement1.setString(6, asset.country)
                statement1.setString(7, asset.zipcode)
                statement1.setString(8, asset.lessor_id)
                statement1.setString(9,asset.currentOccupantID)
                statement1.setString(10, asset.status)
                statement1.setString(11, asset.approvedBy)


                println(statement)


                statement.executeUpdate()
                statement1.executeUpdate()
                println("values inserted")
            }


        } catch (se: SQLException) {
            System.out.println(se.message)




        } finally {
            //closeConnection(connection, statement, rs)
        }
        return asset_id
    }
    fun approveAsset(AdminNode:String,LessorNode: String,assetDetails: List<AssetDTO>):String?
    {
        var asset_id: String? =""
        val  connection = DatabaseConnection.getConnection(AdminNode)
        val  connection1 = DatabaseConnection.getConnection(LessorNode)
        var statement: PreparedStatement? = null
        var statement1: PreparedStatement? = null

        try {
            val sql1: String? = "Update AssetDetailsTableT5 set status=?,approvedBy=? where asset_id =?"
            for(asset in assetDetails) {
                asset_id= asset.asset_id
                statement = connection.prepareStatement(sql1)
                statement1 = connection1.prepareStatement(sql1)
                statement.setString(1, "Approved-Available")
                statement.setString(2, asset.approvedBy)
                statement.setString(3, asset.asset_id)
                statement1.setString(1, "Approved-Available")
                statement1.setString(2, asset.approvedBy)
                statement1.setString(3, asset.asset_id)

                println(statement)

                statement.executeUpdate()
                statement1.executeUpdate()
                println("values inserted")
            }



        } catch (se: SQLException) {
            System.out.println(se.message)




        } finally {
            //closeConnection(connection, statement, rs)
        }
        return asset_id
    }

//
//    fun deleteAssetDetails(Adminnode: String,Lessornode: String)
//    {
//        val connection=DatabaseConnection.getConnection(Adminnode)
//        val connection1=DatabaseConnection.getConnection(Lessornode)
//        var statement: PreparedStatement?= null
//        var statement1: PreparedStatement?= null
//        try {
//
//            val sql: String? ="delete from AssetDetailsTableT5"
//            statement = connection.prepareStatement(sql)
//            statement1 = connection1.prepareStatement(sql)
//            statement.executeUpdate()
//            statement1.executeUpdate()
//
//        }catch (se: SQLException) {
//            System.out.println(se.message)
//
//        } finally {
//            //closeConnection(connection, statement, rs)
//        }
//    }
//
//    fun deleteContractDetails(Lessornode: String,LesseeNode: String)
//    {
//        val connection=DatabaseConnection.getConnection(Lessornode)
//        val connection1=DatabaseConnection.getConnection(Lessornode)
//        var statement: PreparedStatement?= null
//        var statement1: PreparedStatement?= null
//        try {
//
//            val sql: String? ="delete from contractDetailsTableTT5"
//            statement = connection.prepareStatement(sql)
//            statement1 = connection1.prepareStatement(sql)
//            statement.executeUpdate()
//            statement1.executeUpdate()
//
//            val sql1: String? ="delete from paymentListTableTT5"
//            statement = connection.prepareStatement(sql1)
//            statement1 = connection1.prepareStatement(sql1)
//            statement.executeUpdate()
//            statement1.executeUpdate()
//
//
//        }catch (se: SQLException) {
//            System.out.println(se.message)
//
//        } finally {
//            //closeConnection(connection, statement, rs)
//        }
//    }
//
    fun submitContract(Lessornode: String,LesseeNode: String,ContractDetails: List<ContractDTO>):String?
    {
        println("inside submit contract")
        var contract_id: String? =""
        val  connection = DatabaseConnection.getConnection(Lessornode)
        val  connection1 = DatabaseConnection.getConnection(LesseeNode)
        var statement: PreparedStatement? = null
        var statement1: PreparedStatement? = null
        var  schedule_id:String=""

        try {
            val sql1: String? = "Update   contractDetailsTableTT5 set status=? where contract_id =?"
            for(contract in ContractDetails) {
                contract_id= contract.contract_id
                println("comments============="+contract.comments)
                statement = connection.prepareStatement(sql1)
                statement1 = connection1.prepareStatement(sql1)
                for(contract in ContractDetails) {
                    if(contract.status=="Initiated"||contract.status=="Saved") {
                        statement.setString(1, "Waiting Review")
                        statement.setString(2, contract.contract_id)
                        statement1.setString(1, "Waiting Review")
                        statement1.setString(2, contract.contract_id)
                        println(statement)
                        statement.executeUpdate()
                        statement1.executeUpdate()
                        println("values inserted")
                    }
                }
            }



        } catch (se: SQLException) {
            System.out.println(se.message)




        } finally {
            //closeConnection(connection, statement, rs)
        }
        return contract_id
    }
    fun sendBackReview(LesseeNode: String,LessorNode: String,ContractDetails: List<ContractDTO>):String?
    {
        var contract_id: String? =""
        val  connection = DatabaseConnection.getConnection(LesseeNode)
        val  connection1 = DatabaseConnection.getConnection(LessorNode)
        var statement: PreparedStatement? = null
        var statement1: PreparedStatement? = null

        try {
            val sql1: String? = "Update contractDetailsTableTT5 set status=?,comments=? where contract_id =?"
            for(contract in ContractDetails) {
                contract_id= contract.contract_id
                println("comments============="+contract.comments)
                statement = connection.prepareStatement(sql1)
                statement1 = connection1.prepareStatement(sql1)
                statement.setString(1, "Under Revision")
                statement.setString(2,contract.comments)
                statement.setString(3, contract.contract_id)
                statement1.setString(1, "Under Revision")
                statement1.setString(2,contract.comments)
                statement1.setString(3, contract.contract_id)
                println(statement)
                statement.executeUpdate()
                statement1.executeUpdate()
                println("values inserted")
            }



        } catch (se: SQLException) {
            System.out.println(se.message)




        } finally {
            //closeConnection(connection, statement, rs)
        }
        return contract_id
    }
    fun saveContract(Lessornode: String,LesseeNode: String,ContractDetails: List<ContractDTO>):String?
    {
        var contract_id: String? =""
        val  connection = DatabaseConnection.getConnection(Lessornode)
        val  connection1 = DatabaseConnection.getConnection(LesseeNode)
        var statement: PreparedStatement? = null
        var statement1: PreparedStatement? = null

        try {
            val sql1: String? = "Update  contractDetailsTableTT5 set status=?,comments=? where contract_id =?"
            for(contract in ContractDetails) {
                contract_id= contract.contract_id
                println("comments============="+contract.comments)
                statement = connection.prepareStatement(sql1)
                statement1 = connection1.prepareStatement(sql1)
                statement.setString(1, "Saved")
                statement.setString(2,contract.comments)
                statement.setString(3, contract.contract_id)
                statement1.setString(1, "Saved")
                statement1.setString(2,contract.comments)
                statement1.setString(3, contract.contract_id)
                println(statement)
                statement.executeUpdate()
                statement1.executeUpdate()
                println("values inserted")
            }



        } catch (se: SQLException) {
            System.out.println(se.message)




        } finally {
            //closeConnection(connection, statement, rs)
        }
        return contract_id
    }

    fun ApproveContract(LesseeNode: String,LessorNode: String,ContractDetails: List<ContractDTO>):String?
    {
        var contract_id: String? =""
        val  connection = DatabaseConnection.getConnection(LesseeNode)
        val  connection1 = DatabaseConnection.getConnection(LessorNode)
        var statement: PreparedStatement? = null
        var statement1: PreparedStatement? = null

        try {
            val sql1: String? = "Update contractDetailsTableTT5 set status=?,comments=? where contract_id =?"
            for(contract in ContractDetails) {
                contract_id= contract.contract_id
                println("comments============="+contract.comments)
                statement = connection.prepareStatement(sql1)
                statement1 = connection1.prepareStatement(sql1)
                statement.setString(1, "Lessee Signed")
                statement.setString(2,contract.comments)
                statement.setString(3, contract.contract_id)
                statement1.setString(1, "Lessee Signed")
                statement1.setString(2,contract.comments)
                statement1.setString(3, contract.contract_id)
                println(statement)
                statement.executeUpdate()
                statement1.executeUpdate()
                println("values inserted")
            }



        } catch (se: SQLException) {
            System.out.println(se.message)




        } finally {
            //closeConnection(connection, statement, rs)
        }
        return contract_id
    }

    fun lessorSign(Lessornode: String,LesseeNode: String,ContractDetails: List<ContractDTO>):String?
    {   var schedule_id:String =""
        var contract_id: String? =""
        val  connection = DatabaseConnection.getConnection(Lessornode)
        val  connection1 = DatabaseConnection.getConnection(LesseeNode)
        var statement: PreparedStatement? = null
        var statement1: PreparedStatement? = null

        try {
            val sql1: String? = "Update contractDetailsTableTT5 set status=?,comments=? where contract_id =?"
            for(contract in ContractDetails) {
                contract_id= contract.contract_id
                println("comments============="+contract.comments)
                statement = connection.prepareStatement(sql1)
                statement1 = connection1.prepareStatement(sql1)
                statement.setString(1, "Fully Signed")
                statement.setString(2,contract.comments)
                statement.setString(3, contract.contract_id)
                statement1.setString(1, "Fully Signed")
                statement1.setString(2,contract.comments)
                statement1.setString(3, contract.contract_id)
                println(statement)
                statement.executeUpdate()
                statement1.executeUpdate()
                println("values inserted")

                val sql2: String? = "CREATE TABLE IF NOT EXISTS paymentschedule5(schedule_id varchar(50) NULL, contract_id varchar(50)Null,type varchar(50) Null,paymentmonth date Null,amount float Null,totalamount float Null,status varchar(20) Null)"

                statement = connection.prepareStatement(sql2)
                statement1 = connection1.prepareStatement(sql2)
                statement.execute()
                statement1.execute()
                println("table created")

                val sql3: String? = "insert into paymentschedule5 values (?,?,?,?,?,?,?)"
                statement = connection.prepareStatement(sql3)
                statement1 = connection1.prepareStatement(sql3)
                schedule_id = "Sch"+(Math.abs(Math.ceil(Math.random()*1000000))).toString().replace(".0","")
                for(details in ContractDetails)
                {
                    for(payment in details.paymentDetails)
                    {
                        statement.setString(1, schedule_id)
                        statement.setString(2, details.contract_id)
                        statement.setString(3, details.frequency)
                        statement.setDate(4,Date.valueOf(payment.duedate))
                        statement.setFloat(5,payment.amount)
                        statement.setFloat(6, details.amount)
                        statement.setString(7, "NotPaid")
                        statement1.setString(1, schedule_id)
                        statement1.setString(2, details.contract_id)
                        statement1.setString(3, details.frequency)
                        statement1.setDate(4, Date.valueOf(payment.duedate))
                        statement1.setFloat(5,payment.amount)
                        statement1.setFloat(6, details.amount)
                        statement1.setString(7, "NotPaid")
                        println(statement)
                        statement.executeUpdate()
                        statement1.executeUpdate()
                        println("details inserted")
                    }
                }
            }



        } catch (se: SQLException) {
            System.out.println(se.message)




        } finally {
            //closeConnection(connection, statement, rs)
        }
        return contract_id
    }

fun createPaymentHeader(LessorNode:String,filedetails:filedetail):String
{
    println("filedetails"+filedetails)
    val  connection = DatabaseConnection.getConnection(LessorNode)
    var statement: PreparedStatement? = null
    var lessor_id:String=""
    var status:String=""
    var checkstatus:String=""
    var contract_name:String=""
    var header_id:String=""
    var rs: ResultSet? = null

    try {
        val sql1: String? = "CREATE TABLE IF NOT EXISTS PaymentHeader2 (HeaderId VARCHAR(50) PRIMARY KEY,filename varchar(40)NULL, UploadedDate Date NULL, Lessor_id VARCHAR(50) NULL, Status VARCHAR(50) NULL)"
        statement = connection.prepareStatement(sql1)
        statement.execute()
        println("tabled created")
            println("fileDetails"+filedetails.contract_id)
            val sql: String? = "select lessor_id,contract_name,status from contractDetailsTableTT5 where contract_id=?"
            statement = connection.prepareStatement(sql)
            statement.setString(1, filedetails.contract_id)
            rs = statement.executeQuery()
            println("row" + rs)
            while (rs.next()) {
                lessor_id = rs.getString("lessor_id")
                contract_name = rs.getString("contract_name")
                checkstatus=rs.getString("status")
                println("checkstatus"+checkstatus)
            }
        header_id= "Header"+(Math.abs(Math.ceil(Math.random()*1000000))).toString().replace(".0","")
       val sql2:String? = "Insert into PaymentHeader2 values(?,?,?,?,?)"
        statement = connection.prepareStatement(sql2)
        statement.setString(1, header_id)
        statement.setString(2,filedetails.filename)
        statement.setString(4, lessor_id)
        statement.setString(5, "Success")
         for(detail in filedetails.paymentmonth) {
               statement.setDate(3, Date.valueOf(detail))
           }

               statement.executeUpdate()
               println("updated details")
          for(detail in filedetails.paymentmonth) {
               if (checkstatus.equals("Fully Signed")) {
                   val sql3: String? = "Update paymentschedule5 set status =? where contract_id=? and paymentmonth= ? "
                   statement = connection.prepareStatement(sql3)
                   statement.setString(1, "Paid")
                   statement.setString(2, filedetails.contract_id)
                   statement.setString(3, detail)
                   statement.executeUpdate()
                   println(statement)
                   println("updated")
                   status = "Completed"
               }
               else
               {
                   status = "Failed"
               }

           }
        } catch (se: SQLException) {
        System.out.println(se.message)




    } finally {
        //closeConnection(connection, statement, rs)
    }
    return status
}
//
//    fun createVaultAsset(nodeName: String,assetDetails:AssetDTO): String {
//        println("inside dao")
//        println(nodeName)
//        var    asset_id=""
//        val  connection = DatabaseConnection.getConnection(nodeName)
//        println("connectionof table"+connection)
//        println("inside the table creation")
//        var statement: PreparedStatement? = null
//        var rs: ResultSet? = null
//
//
//        try {
//            val sql: String? = "CREATE TABLE IF NOT EXISTS Asset1 (asset_id VARCHAR(50) PRIMARY KEY, name VARCHAR(50) NULL, address VARCHAR(50) NULL, city VARCHAR(50) NULL, state VARCHAR(50) NULL ,country VARCHAR(20) NULL, zipcode VARCHAR(50) NULL,lessor_id VARCHAR(50) NOT NULL, status VARCHAR(50) NULL, approvedBy VARCHAR(50) NULL)"
//
//            statement = connection.prepareStatement(sql)
//
//            statement.execute()
//            println("tablestatement-->"+statement)
//            println("table created")
//
//            asset_id = "Asset"+(Math.abs(Math.ceil(Math.random()*1000000))).toString().replace(".0","")
//            val sql1: String? = "INSERT INTO Asset1(asset_id, name, address, city, state, country, zipcode,lessor_id,status,approvedBy) VALUES (?,?,?,?,?,?,?,?,?,?)"
//            println("table created")
//            println("Asset-->"+assetDetails)
//
//            statement = connection.prepareStatement(sql1)
//
//            statement.setString(1, asset_id)
//            statement.setString(2, assetDetails.name)
//            statement.setString(3, assetDetails.address)
//            statement.setString(4, assetDetails.city)
//            statement.setString(5, assetDetails.state)
//            statement.setString(6, assetDetails.country)
//            statement.setString(7, assetDetails.zipcode)
//            statement.setString(8, assetDetails.lessor_id)
//            statement.setString(9, assetDetails.status)
//            statement.setString(10, assetDetails.approvedBy)
//
//
//
//            println(statement)
//
//
//            statement.executeUpdate()
//            println("values inserted")
//
//
//
//        } catch (se: SQLException) {
//            System.out.println(se.message)
//
//
//
//
//        } finally {
//            //closeConnection(connection, statement, rs)
//        }
//        return asset_id
//    }
//
//
//
    fun createUser(nodeName: String,UserDetails: List<UserDetailsDTO>): String {
        println("inside dao")
        println(nodeName)
        var    User_id=""
        val  connection = DatabaseConnection.getConnection(nodeName)
        println("connectionof table"+connection)
        println("inside the table creation")
        var statement: PreparedStatement? = null
        var rs: ResultSet? = null
        try {
            val sql: String? = "CREATE TABLE IF NOT EXISTS UserDetailsT1 (user_id VARCHAR(50) PRIMARY KEY, name VARCHAR(50) NULL, address VARCHAR(50) NULL,contactno VARCHAR(50) NULL, city VARCHAR(50) NULL, state VARCHAR(50) NULL ,country VARCHAR(20) NULL, zipcode VARCHAR(50) NULL)"
            statement = connection.prepareStatement(sql)
            statement.execute()
            println("tablestatement-->"+statement)
            println("table created")
            User_id = "Les"+(Math.abs(Math.ceil(Math.random()*1000000))).toString().replace(".0","")
            val sql1: String? = "INSERT INTO UserDetailsT1(user_id, name, address, contactno, city, state, country, zipcode) VALUES (?,?,?,?,?,?,?,?)"
            println("table created")
            println("UserDetails-->"+UserDetails)
            for(user in UserDetails) {
                statement = connection.prepareStatement(sql1)
                statement.setString(1, User_id)
                statement.setString(2, user.name)
                statement.setString(3, user.address)
                statement.setString(4, user.contact_no)
                statement.setString(5, user.city)
                statement.setString(6, user.state)
                statement.setString(7, user.country)
                statement.setString(8, user.zipcode)
                println(statement)
                statement.executeUpdate()
                println("values inserted")
            }
        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
        }
        return User_id
    }

//
    fun getAssetDetails(nodeName: String ): List<AssetDTO> {
        println("inside the viewContract")
        println(nodeName)
        val  connection = DatabaseConnection.getConnection(nodeName)
        println("connection"+connection)
        var assetList : MutableList<AssetDTO> = mutableListOf()
        var statement: PreparedStatement? = null
        var rs: ResultSet? = null

        var whereClause = StringBuilder()

        try {

            //  val sql: String? = "SELECT contract_id AS contract_id, contract_name, lesse_name, description, start_date, end_date, frequency from RegisterCustomer where contract_name=contract_name"
            val sql: String? ="select * from AssetDetailsTableT5"
            statement = connection.prepareStatement(sql)
            System.out.println("SQL: "+sql.toString())
            System.out.println("Statement: "+statement.toString())
            rs = statement.executeQuery()
            println(rs)
            var asset : AssetDTO? = null
            while (rs.next()) {
                asset = AssetDTO(rs.getString("asset_id"), rs.getString("name"), rs.getString("address"),rs.getString("city"),rs.getString("state"),rs.getString("country"),rs.getString("zipcode"),rs.getString("lessor_id"),rs.getString("currentOccupantID"),rs.getString("status"),rs.getString("approvedBy"))
                if(null != asset){
                    assetList.add(asset)
                }
            }


        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
            // closeConnection(connection, statement, rs)
        }
        return assetList
    }


    fun getAssetById(nodeName: String,asset_id: String): List<AssetDTO> {
        println("inside the viewContract")
        println(nodeName)
        println("assetid"+asset_id)
        val  connection = DatabaseConnection.getConnection(nodeName)
        println("connection"+connection)
        var assetList : MutableList<AssetDTO> = mutableListOf()
        var statement: PreparedStatement? = null
        var rs: ResultSet? = null

        var whereClause = StringBuilder()

        try {

            //  val sql: String? = "SELECT contract_id AS contract_id, contract_name, lesse_name, description, start_date, end_date, frequency from RegisterCustomer where contract_name=contract_name"
            val sql: String? ="select * from AssetDetailsTableT5 where asset_id=?"
            statement = connection.prepareStatement(sql)
            statement.setString(1,asset_id)
            System.out.println("SQL: "+sql.toString())
            System.out.println("Statement: "+statement.toString())
            rs = statement.executeQuery()
            println(rs)
            var asset : AssetDTO? = null
            while (rs.next()) {
                asset = AssetDTO(rs.getString("asset_id"), rs.getString("name"), rs.getString("address"),rs.getString("city"),rs.getString("state"),rs.getString("country"),rs.getString("zipcode"),rs.getString("lessor_id"),rs.getString("currentOccupantID"),rs.getString("status"),rs.getString("approvedBy"))
                if(null != asset){
                    assetList.add(asset)
                }
            }


        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
            // closeConnection(connection, statement, rs)
        }
        return assetList
    }


    fun getFileStatus(nodeName: String): List<FileStatusDTO> {
        println("inside the viewContract")
        println(nodeName)
        val  connection = DatabaseConnection.getConnection(nodeName)
        println("connection"+connection)
        var statusList : MutableList<FileStatusDTO> = mutableListOf()
        var statement: PreparedStatement? = null
        var rs: ResultSet? = null

        var whereClause = StringBuilder()

        try {

            //  val sql: String? = "SELECT contract_id AS contract_id, contract_name, lesse_name, description, start_date, end_date, frequency from RegisterCustomer where contract_name=contract_name"
            val sql: String? ="select filename,Lessor_id,status,UploadedDate from PaymentHeader2"
            statement = connection.prepareStatement(sql)
            System.out.println("SQL: "+sql.toString())
            System.out.println("Statement: "+statement.toString())
            rs = statement.executeQuery()
            println(rs)
            var status : FileStatusDTO? = null
            while (rs.next()) {
                var uploadedDate=rs.getString("UploadedDate").toString()
                status = FileStatusDTO(rs.getString("filename"), rs.getString("Lessor_id"), rs.getString("status"),uploadedDate)
                if(null != status){
                    statusList.add(status)
                }
            }


        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
            // closeConnection(connection, statement, rs)
        }
        return statusList
    }


    fun getContractDetailById(nodeName: String,contract_id:String ): List<ContractDTO> {
        println("inside the viewContract")
        println(nodeName)
        val  connection = DatabaseConnection.getConnection(nodeName)
        println("connection"+connection)
        var contractList : MutableList<ContractDTO> = mutableListOf()
        var paymentList : MutableList<PaymentDTO> = mutableListOf()
        var statement: PreparedStatement? = null
        var rs: ResultSet? = null
        var rs1: ResultSet? = null

        var whereClause = StringBuilder()

        try {
            //  val sql: String? = "SELECT contract_id AS contract_id, contract_name, lesse_name, description, start_date, end_date, frequency from RegisterCustomer where contract_name=contract_name"
            val sql: String? ="select * from  contractDetailsTableTT5 where contract_id=? "
            statement = connection.prepareStatement(sql)
            statement.setString(1,contract_id);
            System.out.println("SQL: "+sql.toString())
            System.out.println("Statement: "+statement.toString())
            rs = statement.executeQuery()
            println(rs)
            var contract : ContractDTO? = null
            var payment :PaymentDTO?=null
            while (rs.next()) {
                paymentList = mutableListOf()
                println("comments-----------------------------------------------"+rs.getString("comments"))
//                    var paymentDetailList =(rs.getString("paymentDetails"))
                val sql1: String? ="select * from  paymentListTableTT5 where contract_id =? "
                statement = connection.prepareStatement(sql1)
                statement.setString(1, contract_id);
                System.out.println("SQL: "+sql1.toString())
                System.out.println("Statement: "+statement.toString())
                rs1 = statement.executeQuery()
                println("paymnet--->"+rs1)
                while(rs1.next())
                {
                    payment=PaymentDTO(rs1.getFloat("amount"),rs1.getString("duedate"))
                    println("payment"+payment)
                    paymentList.add(payment)
                    println("paymentList"+paymentList)
                }
//                    println(paymentDetailList.toCharArray())
                contract = ContractDTO(rs.getString("contract_id"),rs.getString("AssetRefID") ,rs.getString("contract_name"), rs.getString("description"),rs.getString("start_date"),rs.getString("end_date"),rs.getString("frequency"),rs.getFloat("amount"),rs.getString("lessor_id"),rs.getString("lesse_id"),rs.getString("status"),rs.getString("comments"),paymentList,rs.getInt("breachPeriod"))

                if(null != contract){

                    contractList.add(contract)
                }
            }


        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
            // closeConnection(connection, statement, rs)
        }
        return contractList
    }








//
//fun viewCustomer(nodeName: String, contract_name : String): List<ContractDTO> {
//    println(nodeName)
//        val  connection = "conn12: url=jdbc:h2:tcp://172.31.42.10:59003/node user=SA"
//
//         println(connection)
//        var rejectedCustomers : MutableList<ContractDTO> = mutableListOf()
//
//        var statement: PreparedStatement? = null
//        var rs: ResultSet? = null
//
//    var whereClause = StringBuilder()
//
//
//        if(null!=contract_name && !"".equals(contract_name.trim())){
//            whereClause.append(" AND C.contract_name=?")
//        }
//
//        val sql: String? = "SELECT C.contract_id AS contract_id, contract_name, lesse_name, description, start_date, end_date, frequency," + whereClause +
//                " ORDER BY C.contract_name ASC"
//
//        statement = connection.prepareStatement(sql)
//
//        try{
//            statement = connection.prepareStatement(sql)
//            statement.setString(1,contract_name )
//
//            System.out.println("SQL: "+sql.toString())
//            System.out.println("Statement: "+statement.toString())
//
//            rs = statement.executeQuery()
//
//            var customer : ContractDTO? = null
//            while (rs.next()) {
//
//                customer = ContractDTO(rs.getString("contract_id"), rs.getString("contract_name"), rs.getString("lesse_name"), rs.getString("description"), rs.getString("start_date"), rs.getString("end_date"), rs.getString("frequency"))
//                }
//
//
//            if(null != customer){
//
//                rejectedCustomers.add(customer)
//            }
//        } catch (se: SQLException) {
//           System.out.println(se.message)
//        } finally {
//            closeConnection(connection, statement, rs)
//        }
//        return rejectedCustomers
//    }
//
//    private fun closeConnection(connection: Connection?, statement: Statement?, rs: ResultSet?) {
//        try {
//            rs?.close()
//            statement?.close()
//            connection?.close()
//        } catch (e: SQLException) {
//            e.printStackTrace()
//        }
//    }
////
////    fun  deletePermanent(nodeName: String, customer_id: String) {
////        val  connection = DatabaseConnection.getConnection(nodeName)
////
////        var statement: PreparedStatement? = null
////        var rs: ResultSet? = null
////
////        val sql: String? = "DELETE FROM CONTRACT_CUSTOMER WHERE CUSTOMER_ID = ?"
////
////        try {
////            statement = connection.prepareStatement(sql)
////            statement.setString(1, customer_id)
////            statement.execute()
////        } catch (se: SQLException) {
////            System.out.println(se.message)
////        } finally {
////            closeConnection(connection, statement, rs)
////        }
////
////    }
}
