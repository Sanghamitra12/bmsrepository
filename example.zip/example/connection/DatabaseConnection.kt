package com.example.connection


import java.sql.Connection
import java.sql.DriverManager
import java.net.InetAddress

/**
 * Created by 397947 on 5/26/2017.
 */

object DatabaseConnection {
    fun getConnection(nodeName: String) : Connection {
        var port : String = getPort(nodeName)
        println("port"+port)
        Class.forName("org.h2.Driver")
        println("h2 driver")
        println(port)
        val dbConnectionString = "jdbc:h2:tcp://"+getSystemIpAddress()+":$port/node"
        val con = DriverManager.getConnection(
                dbConnectionString, "sa", "")
       println("connectionstring"+con)
        return con
    }

    fun getSystemIpAddress() : String {
        try {
             println("Systemaddress")
            val ipAddr = InetAddress.getLocalHost()
            println(ipAddr.hostAddress)
            return ipAddr.hostAddress
        } catch (ex: Exception) {
            System.out.println(ex.message)
            return "Exeption in getting host address"
        }
    }

    fun getPort(nodeName : String) : String {
        var port = ""
        if(("C=GB,L=London,O=PartyA").equals(nodeName)){
            port = "59003"
        } else if(("C=US,L=New York,O=PartyB").equals(nodeName)){
            port = "59004"
        } else if(("C=FR,L=Paris,O=PartyC").equals(nodeName)){
            port = "59005"
        } else if(("C=FR,L=Rome,O=PartyD").equals(nodeName)){
            port = "59006"
        }
        return port
    }


}