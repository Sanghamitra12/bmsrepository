package com.example.DTO

import net.corda.core.serialization.CordaSerializable
import java.io.InputStream

/**
 * Created by 397947 on 5/24/2017.
 */
@CordaSerializable
data class AssetDTO(

        var asset_id: String?,
        var name: String?,
        var address: String?,
        var city: String?,
        var state: String?,
        var country: String?,
        var zipcode: String?,
        var lessor_id: String?,
        var currentOccupantID: String?,
        var status: String?,
        var approvedBy: String?


)