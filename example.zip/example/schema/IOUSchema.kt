package com.example.schema

import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import java.util.*
import javax.persistence.*
import javax.persistence.Entity
import javax.persistence.Table
import org.hibernate.annotations.Cascade
import org.hibernate.annotations.CascadeType

/**
 * The family of schemas for AssetState.
 */
object IOUSchema

/**
 * An AssetState schema.
 */
object IOUSchemaV1 : MappedSchema(
        schemaFamily = IOUSchema.javaClass,
        version = 1,
        mappedTypes = listOf(PersistentIOU::class.java,contract::class.java,paymentDetails::class.java)) {
    @Entity
    @Table(name = "iou_states")
    class PersistentIOU(
            @Column(name = "user_id")
            var user_id: String,

            @Column(name = "user_type")
            var user_type: String,

            @Column(name = "password")
            var password: String



    ) : PersistentState()
    @Entity
    @Table(name = "contract_details")
    class contract(
            @Column(name = "contract_id")
            var contract_id: String,

            @Column(name="AssetRefID")
            var AssetRefID: String,

            @Column(name = "contract_name")
            var contract_name: String,

            @Column(name = "lessor_id")
            var lessor_id: String,

            @Column(name = "lesse_id")
            var lesse_id: String,

            @Column(name = "description")
            var description: String,

            @Column(name = "start_date")
            var start_date: String,

            @Column(name = "end_date")
            var end_date: String,

            @Column(name = "frequency")
            var frequency: String,

            @Column(name = "amount")
            var amount: Float,

            @Column(name = "status")
            var status: String,

            @Column(name = "comments")
            var comments: String,

            @OrderColumn
            @Cascade(CascadeType.PERSIST) var paymentDetails: List<paymentDetails>? = listOf(),

            @Column(name="breachPeriod")
            var breachPeriod: Int
            ) : PersistentState()

    @Entity
    @Table(name = "paymentDetails")
    class paymentDetails(
            @Column(name = "amount")
            var amount: Float?,

            @Column(name = "duedate")
            var duedate: String?

    )


    @Entity
    @Table(name ="assetDetails")
    class assetDetails(
            @Column(name = "asset_id")
            var asset_id: String?,

            @Column(name = "name")
            var name: String?,

            @Column(name = "address")
            var address: String?,

            @Column(name = "city")
            var city: String?,

            @Column(name = "state")
            var state: String?,

            @Column(name = "country")
            var country: String?,

            @Column(name="zipcode")
            var zipcode: String?,

            @Column(name="lessor_id")
            var lessor_id: String?,

            @Column(name="currentOccupantID")
            var currentOccupantID: String?,

            @Column(name="status")
            var status: String?,

            @Column(name="approvedBy")
            var approvedBy: String?

            ) : PersistentState()


}