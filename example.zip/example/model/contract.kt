package com.example.model
import net.corda.core.serialization.CordaSerializable

/**
 * Created by 397947 on 6/2/2017.
 */
/**
 * A simple class representing an Customer.
 *
 * This is the data structure that the parties will reach agreement over. These data structures can be arbitrarily
 * complex. See https://github.com/corda/corda/blob/master/samples/irs-demo/src/main/kotlin/net/corda/irs/contract/IRS.kt
 * for a more complicated example.
 *
 * @param value the Customer's value.
 */
@CordaSerializable
data class contract(
        var contract_id: String?,
        var AssetRefID:String?,
        var contract_name: String?,
        var description: String?,
        var start_date: String?,
        var end_date: String?,
        var frequency: String?,
        var amount: Float,
        var lessor_id: String?,
        var lesse_id: String?,
        var status: String?,
        var comments: String?,
        var paymentDetails:List<paymentDetails>,
        var breachPeriod:Int



) {
    override fun toString(): String {
        return "contract(contract_id=$contract_id,AssetRefID='$AssetRefID', contract_name='$contract_name' description='$description', start_date='$start_date', end_date='$end_date', frequency='$frequency',amount='$amount',lessor_id='$lessor_id',lesse_id='$lesse_id',status='$status',comments='$comments',paymentDetails='$paymentDetails',breachPeriod='$breachPeriod')"
    }

    override fun equals(other: Any?): Boolean {
        return super.equals(other)
    }

    override fun hashCode(): Int {
        return super.hashCode()
    }
}



